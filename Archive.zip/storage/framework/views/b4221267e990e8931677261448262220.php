<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <br />
        <br />

        <div class="row">

             
            <div class="col-12 col-md-12 col-lg-12">


                <div class="d-flex flex-row justify-space-between "
                    style="width:100%; justify-content:space-between; align-items:center">

                    <h5>Orders</h5>



                </div>
                <br />
                <br />


                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>SN</th>
                          
                            <th>Customer name</th>
                            <th>Customer Email</th>
                            <th>Address</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Date Ordered</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 1;
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="border-bottom: 1px solid grey">
                                <td><?php echo e($count); ?></td>
                                 <td><?php echo e($result->firstname); ?> <?php echo e($result->lastname); ?></td>
                                <td><?php echo e($result->mail); ?> </td>
                                <td><?php echo e($result->address); ?> </td>
                                <td><?php echo e(number_format($result->total)); ?></td>
                                
                                <td><span class="<?php echo e($result->status ? 'text-beige' : 'text-danger'); ?>">
                                        <?php echo e($result->status ? 'Processed' : 'Pending'); ?></span></td>
                                <td><?php echo e($result->created_at); ?></td>

                                <td>

                                    <a href="/admin/order-details/<?php echo e($result->id); ?>" style="font-size:13px"
                                        class="btn btn-info btn-small" style="width:150px;">
                                        View Order
                                    </a>
                                    <a href="/admin/delete-order/<?php echo e($result->id); ?>" style="font-size:13px"
                                        class="btn btn-danger btn-small" style="width:150px;">
                                        Delete
                                    </a>
                                </td>
                            </tr>

                            <?php
                                $count += 1;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>

                </table>

            </div>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mobez/resources/views/admin/orders.blade.php ENDPATH**/ ?>