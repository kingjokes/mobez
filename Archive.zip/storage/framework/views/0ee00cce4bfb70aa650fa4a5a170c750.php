<?php if (isset($component)) { $__componentOriginal7ae6b45c011e855a5545a671a7f3568e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>



    <main style="padding:90px 0">
        <div class="mb-4 pb-4"></div>
        <section class="login-register container">
            <h2 class="d-none">Admin Login </h2>
            <ul class="nav nav-tabs mb-5" id="login_register" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link nav-link_underscore active" id="login-tab" data-bs-toggle="tab"
                        href="#tab-item-login" role="tab" aria-controls="tab-item-login"
                        aria-selected="true">Login</a>
                </li>

            </ul>
            <div class="tab-content pt-2" id="login_register_tab_content">
                <div class="tab-pane fade active show" id="tab-item-login" role="tabpanel" aria-labelledby="login-tab">
                    <div class="login-form">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                        <form name="login-form" action="/admin/check-login" method="POST" class="needs-validation"
                            novalidate="">

                            <?php echo csrf_field(); ?>
                            <div class="form-floating mb-3">
                                <input name="login_email" type="email" class="form-control form-control_gray"
                                    id="customerNameEmailInput1" placeholder="Email address *" required="">
                                <label for="customerNameEmailInput1">Email address *</label>
                            </div>

                            <div class="pb-3"></div>

                            <div class="form-floating mb-3">
                                <input name="login_password" type="password" class="form-control form-control_gray"
                                    id="customerPasswodInput" placeholder="Password *" required="">
                                <label for="customerPasswodInput">Password *</label>
                            </div>

                            <div class="d-flex align-items-center mb-3 pb-2">
                                <div class="form-check mb-0">
                                    <input name="remember" class="form-check-input form-check-input_fill"
                                        type="checkbox" value="" id="flexCheckDefault1">
                                    <label class="form-check-label text-secondary" for="flexCheckDefault1">Remember
                                        me</label>
                                </div>
                                <a href="./reset_password.html" class="btn-text ms-auto d-none">Lost password?</a>
                            </div>

                            <button class="btn btn-primary w-100 text-uppercase" type="submit">Log In</button>

                            <div class="customer-option mt-4 text-center d-none">
                                <span class="text-secondary">No account yet?</span>
                                <a href="#register-tab" class="btn-text js-show-register">Create Account</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </section>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $attributes = $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $component = $__componentOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mobez/resources/views/admin/login.blade.php ENDPATH**/ ?>