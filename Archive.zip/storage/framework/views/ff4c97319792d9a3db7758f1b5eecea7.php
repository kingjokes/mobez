<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <br />
        <br />

        <div class="row">

            <div class="col-1 col-md-1 col-lg-1">


            </div>
            <div class="col-12 col-md-5 col-lg-5">


                <h3>Settings</h3>



                <br />


                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <div>
                    <h6>E-commerce Currency</h6>
                    <br />
                    <form name="login-form" action="/admin/update-settings" method="POST">

                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-4">
                            <input name="name" value="<?php echo e($currency->name); ?>" hidden />
                            <select name="value" value="<?php echo e($currency->value); ?>"required="required"
                                class="form-control form-control_gray" id="status">
                                <option value="">select currency</option>
                                <option value="$" <?php echo e($currency->value == '$' ? 'selected' : ''); ?>>
                                    Dollars ($)
                                </option>
                                <option value="£" <?php echo e($currency->value == '£' ? 'selected' : ''); ?>>
                                    Pounds (£)
                                </option>
                                <option value="€" <?php echo e($currency->value == '€' ? 'selected' : ''); ?>>
                                    Euros (€)
                                </option>
                                <option value="₦" <?php echo e($currency->value == '₦' ? 'selected' : ''); ?>>
                                    Naira (₦)
                                </option>


                            </select>
                            <label for="status">Currency *</label>

                        </div>



                        <button class="btn btn-primary w-100 " type="submit">Update Currency</button>


                    </form>

                </div>

                <br />
                <br />

                <div>
                    <h6>Change Password</h6>
                    <br />
                    <form name="login-form" action="/admin/change-password" method="POST">

                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-4">
                            <input name="oldPassword" type="password" required="required"
                                class="form-control form-control_gray" id="oldPassword" />
                            <label for="oldPassword">Old Password</label>
                        </div>

                        <div class="form-floating mb-4">
                            <input name="newPassword" type="password" min="6" required="required"
                                class="form-control form-control_gray" id="newPassword" />
                            <label for="newPassword">New Password</label>
                        </div>

                        <div class="form-floating mb-4">
                            <input name="cPassword" type="password" min="6" required="required"
                                class="form-control form-control_gray" id="cPassword" />
                            <label for="cPassword">Confirm Password</label>
                        </div>





                        <button class="btn btn-primary w-100 " type="submit">Update Password</button>


                    </form>
                </div>





            </div>

        </div>


    </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mobez/resources/views/admin/settings.blade.php ENDPATH**/ ?>