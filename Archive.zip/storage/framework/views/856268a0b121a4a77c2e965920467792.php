<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <br />
        <br />

        <div class="row">


            <div class="col-12 col-md-1 col-lg-1"></div>
            <div class="col-12 col-md-10 col-lg-10">


                <div class="d-flex flex-row justify-space-between "
                    style="width:100%; justify-content:space-between; align-items:center">

                    <h5>Order Details - <b>#<?php echo e($details->id); ?></b></h5>



                </div>
                <br />
                <br />


                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <table class="table">

                    <tbody>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Order Id</b></td>
                            <td>#<?php echo e($details->id); ?></td>

                        </tr>


                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Customer Details</b></td>
                            <td><?php echo e($details->firstname); ?> <?php echo e($details->lastname); ?></td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Customer Email</b></td>
                            <td><?php echo e($details->mail); ?> </td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Address</b></td>
                            <td><?php echo e($details->address); ?></td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Town</b></td>
                            <td><?php echo e($details->town); ?></td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Country</b></td>
                            <td><?php echo e($details->country); ?></td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Postal Code</b></td>
                            <td><?php echo e($details->postal_code); ?></td>

                        </tr>

                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Order Note </b></td>
                            <td><?php echo e($details->order_notes); ?></td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Order Breakdown </b></td>
                            <td>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Image</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                        </tr>

                                    </thead>
                                    <tbody id="order-content">


                                    </tbody>

                                </table>

                            </td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Total </b></td>
                            <td><b><?php echo e(number_format($details->total)); ?></b></td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Date Ordered </b></td>
                            <td><?php echo e($details->created_at); ?></td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Order Status </b></td>
                            <td><span class="<?php echo e($details->status ? 'text-beige' : 'text-danger'); ?>">
                                    <?php echo e($details->status ? 'Processed' : 'Pending'); ?></span>
                            </td>

                        </tr>
                        <tr style="border-bottom: 1px solid grey">
                            <td><b>Update Order Status </b></td>
                            <td>
                                <form name="login-form" action="/admin/update-order" method="POST"
                                    style="max-width:400px!important">

                                    <?php echo csrf_field(); ?>
                                    <div class="form-floating mb-4">
                                        <input name="id" value="<?php echo e($details->id); ?>" hidden />
                                        <select name="status" value="<?php echo e($details->status); ?>"required="required"
                                            class="form-control form-control_gray" id="status">
                                            <option value="">select status</option>
                                            <option value="1" <?php echo e($details->status == 1 ? 'selected' : ''); ?>

                                                class="text-success">
                                                Processed
                                            </option>
                                            <option value="0" <?php echo e($details->status == 0 ? 'selected' : ''); ?>

                                                class="text-danger">
                                                Pending
                                            </option>

                                        </select>
                                        <label for="status">Order Status *</label>

                                    </div>



                                    <button class="btn btn-primary w-100 text-uppercase" type="submit">Update
                                        Status</button>


                                </form>
                            </td>

                        </tr>
                    </tbody>

                </table>

            </div>

        </div>

        <script>
            function htmlDecode(input) {
                var doc = new DOMParser().parseFromString(input, "text/html");
                return doc.documentElement.textContent;
            }

            const formatAmount = (nStr) => {
                if (nStr === undefined) return 0;
                nStr += "";
                let x = nStr.split(".");
                let x1 = x[0];
                let x2 = x.length > 1 ? "." + x[1] : "";
                let rgx = /(\d+)(\d{3})/;
                while (rgx.test(x1)) {
                    x1 = x1.replace(rgx, "$1" + "," + "$2");
                }
                return x1 + x2;
            };


            const listOrders = (array) => {
                let data = ``

                JSON.parse(array || "[]").map(item => {

                    data += `<tr>
                                        <td class="text-capitalize"><b>${item.name}</b></td>
                                        <td><img src="${item.image}" style="width:90px; height:90px" /></td>
                                        <td><span>${item.quantity}</span></td>
                                        <td><b>${formatAmount(item.quantity * item.price)}</b></td>
                                        
                                </tr>
                `
                })

                document.getElementById("order-content").innerHTML = data




            }
            listOrders(htmlDecode('<?php echo e($details->order_breakdown); ?>'))
        </script>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mobez/resources/views/admin/order-details.blade.php ENDPATH**/ ?>