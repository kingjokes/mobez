<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <br />
    <br />

    <div class="row">

        <div class="col-12 col-md-1 col-lg-1">


        </div>
        <div class="col-12 col-md-10 col-lg-10">
            <h3>Edit Product - (<?php echo e($details->name); ?>)</h3>
            <br />
            <br />

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <form name="login-form" action="/admin/edit-product" method="POST" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                <input name="id" value="<?php echo e($details->id); ?>" hidden />
                <div class="form-floating mb-4">
                    <input value="<?php echo e($details->name); ?>" name="name" type="text" required="required"
                        class="form-control form-control_gray" id="name" placeholder="Enter product name">
                    <label for="name">Product Name *</label>


                </div>
                <div class="form-floating mb-4">
                    <select value="<?php echo e($details->category_id); ?>" name="category"required="required"
                        class="form-control form-control_gray" id="category">
                        <option value="">select a category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($details->category_id === $result->id ? 'selected' : ''); ?>

                                value="<?php echo e($result->id); ?>">
                                <?php echo e($result->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="category">Product Category *</label>

                </div>

                <div>
                    <img src="<?php echo e($details->image); ?>" style="width:150px; height:150px" />
                </div>

                <div class="form-floating mb-4">
                    <input name="image" type="file" accept='image/*' class="form-control form-control_gray"
                        id="image" placeholder="Select a product image">
                    <label for="image">Product Main Image *</label>


                </div>

                <div class="form-floating mb-4">
                    <input value="<?php echo e($details->price); ?>" name="price" type="number" min="0"
                        required="required" class="form-control form-control_gray" id="price"
                        placeholder="Enter product price">
                    <label for="name">Product Price *</label>


                </div>

                <div class="form-floating mb-4">
                    <textarea value="<?php echo e($details->short_description); ?>" name="short_description" style="min-height:100px!important"
                        rows="4" type="text" required="required" class="form-control form-control_gray" id="short_description"
                        placeholder="Enter product short description"><?php echo e($details->short_description); ?></textarea>
                    <label for="short_description">Product Short Description *</label>


                </div>

                <div class="form-floating mb-4">
                    <div for="description">Product Full Description *</div>
                    <div id="toolbar-container">
                        <span class="ql-formats">
                            <select class="ql-font"></select>
                            <select class="ql-size"></select>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-bold"></button>
                            <button class="ql-italic"></button>
                            <button class="ql-underline"></button>
                            <button class="ql-strike"></button>
                        </span>
                        <span class="ql-formats">
                            <select class="ql-color"></select>
                            <select class="ql-background"></select>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-script" value="sub"></button>
                            <button class="ql-script" value="super"></button>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-header" value="1"></button>
                            <button class="ql-header" value="2"></button>
                            <button class="ql-blockquote"></button>
                            <button class="ql-code-block"></button>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-list" value="ordered"></button>
                            <button class="ql-list" value="bullet"></button>
                            <button class="ql-indent" value="-1"></button>
                            <button class="ql-indent" value="+1"></button>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-direction" value="rtl"></button>
                            <select class="ql-align"></select>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-link"></button>
                            <button class="ql-image"></button>
                            <button class="ql-video"></button>
                            <button class="ql-formula"></button>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-clean"></button>
                        </span>
                    </div>
                    <div id="editor" style="min-height:200px">
                    </div>

                    <!-- Initialize Quill editor -->
                    <script>
                        function htmlDecode(input) {
                            var doc = new DOMParser().parseFromString(input, "text/html");
                            return doc.documentElement.textContent;
                        }
                        const quill = new Quill('#editor', {
                            modules: {
                                syntax: true,
                                toolbar: '#toolbar-container',
                            },
                            placeholder: 'Enter your product full description....',
                            theme: 'snow',
                        });

                        quill.on('text-change', (delta, oldDelta, source) => {
                            document.getElementById('full_description').value = quill.getSemanticHTML()


                        })
                        window.addEventListener('load', function() {
                            quill.root.innerHTML = htmlDecode("<?php echo e($details->full_description); ?>")
                            document.getElementById('full_description').value = htmlDecode("<?php echo e($details->full_description); ?>")
                        }, false)
                    </script>


                </div>


                <div class="form-floating mb-4">
                    <select name="status" value="<?php echo e($details->status); ?>"required="required"
                        class="form-control form-control_gray" id="status">
                        <option value="">select status</option>
                        <option value="1" <?php echo e($details->status == 1 ? 'selected' : ''); ?> class="text-success">
                            Active
                        </option>
                        <option value="0" <?php echo e($details->status == 0 ? 'selected' : ''); ?> class="text-danger">
                            Inactive
                        </option>

                    </select>
                    <label for="status">Product Status *</label>

                </div>


                <div class='d-flex flex-wrap mb-4' style="gap:10px; width:100%">

                    <?php $__currentLoopData = $product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mx-1">
                            <img src="<?php echo e($image->image); ?>" style="width:100px; height:100px" />
                            <br />
                            <a href='/admin/delete-product-image/<?php echo e($image->id); ?>' class="btn btn-danger"
                                style="font-size:10px!important; width:100px!important; padding:5px!important">
                                Delete Image
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>


                <div class="form-floating mb-4">
                    <input name="product_images[]" type="file" multiple accept='image/*'
                        class="form-control form-control_gray" id="image"
                        placeholder="Select other product images">
                    <label for="product_images">Product Other Images *</label>


                </div>

                <input name="full_description" id="full_description" value="" hidden />






                <div class="pb-3"></div>



                <button class="btn btn-primary w-100 text-uppercase" type="submit">Submit</button>

                <div class="pb-3"></div>
            </form>




        </div>

    </div>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mobez/resources/views/admin/edit-product.blade.php ENDPATH**/ ?>