<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <br />
        <br />

        <div class="row">

            <div class="col-1 col-md-1 col-lg-1">


            </div>
            <div class="col-12 col-md-10 col-lg-10">

                <div class="row">

                    <div class="col-6 col-md-4 col-lg-4" style="">

                        <div style="background-color:lightgrey;padding:20px 20px; border-radius:10px">



                            <h6>
                                Total Products
                            </h6>

                            <h1><?php echo e(number_format($products)); ?></h1>

                        </div>



                    </div>
                    <div class="col-6 col-md-4 col-lg-4" style="">

                        <div style="background-color:lightgrey;padding:20px 20px; border-radius:10px">



                            <h6>
                                Total Orders
                            </h6>

                            <h1><?php echo e(number_format($orders)); ?></h1>

                        </div>



                    </div>
                    <div class="col-6 col-md-4 col-lg-4" style="">

                        <div style="background-color:lightgrey;padding:20px 20px; border-radius:10px">



                            <h6>
                                Total Reviews
                            </h6>

                            <h1><?php echo e(number_format($reviews)); ?></h1>

                        </div>



                    </div>
                    <div class="col-6 col-md-4 col-lg-4" style="">
                    <br/>

                        <div style="background-color:lightgrey;padding:20px 20px; border-radius:10px">



                            <h6>
                                Total Product Images
                            </h6>

                            <h1><?php echo e(number_format($product_images)); ?></h1>

                        </div>



                    </div>
                    <div class="col-6 col-md-4 col-lg-4" style="">
                    <br/>

                        <div style="background-color:lightgrey;padding:20px 20px; border-radius:10px">



                            <h6>
                                Total Categories
                            </h6>

                            <h1><?php echo e(number_format($categories)); ?></h1>

                        </div>



                    </div>

                </div>

            </div>

            <div class="col-1 col-md-1 col-lg-1">




            </div>

        </div>


    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mobez/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>