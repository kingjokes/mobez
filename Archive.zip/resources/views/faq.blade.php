<x-app>
<x-slot:title>
        FAQ | Fashion by Mobez
    </x-slot>
 <main>
    <div class="mb-5 pb-4"></div>
    <section class="container mw-930 lh-30">
      <h2 class="section-title text-uppercase fw-bold mb-5">FREQUENTLY ASKED QUESTIONS</h2>
      <h3 class="mb-4">Orders</h3>      
      <div id="faq_accordion" class="faq-accordion accordion mb-5">
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-1">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-1" aria-expanded="true" aria-controls="faq-accordion-collapse-1">
              Bring of had which their whose you're it own?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-heading-1" data-bs-parent="#faq_accordion">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-2">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2" aria-expanded="false" aria-controls="faq-accordion-collapse-2">
              Over shall air can't subdue fly divide him?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-2" class="accordion-collapse collapse" aria-labelledby="faq-accordion-heading-2" data-bs-parent="#faq_accordion">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-3">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-3" aria-expanded="false" aria-controls="faq-accordion-collapse-3">
              Waters one you'll creeping?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-3" class="accordion-collapse collapse" aria-labelledby="faq-accordion-heading-3" data-bs-parent="#faq_accordion">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
      </div>
      <h3 class="mb-4">Shipping</h3>      
      <div id="faq_accordion_2" class="faq-accordion accordion mb-5">
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-2-1">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2-1" aria-expanded="true" aria-controls="faq-accordion-collapse-2-1">
              Bring of had which their whose you're it own?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-2-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-heading-2-1" data-bs-parent="#faq_accordion_2">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-2-2">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2-2" aria-expanded="false" aria-controls="faq-accordion-collapse-2-2">
              Over shall air can't subdue fly divide him?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-2-2" class="accordion-collapse collapse" aria-labelledby="faq-accordion-heading-2-2" data-bs-parent="#faq_accordion_2">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-2-3">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2-3" aria-expanded="false" aria-controls="faq-accordion-collapse-2-3">
              Waters one you'll creeping?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-2-3" class="accordion-collapse collapse" aria-labelledby="faq-accordion-heading-2-3" data-bs-parent="#faq_accordion_2">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
      </div>
      <h3 class="mb-4">Payment</h3>      
      <div id="faq_accordion_3" class="faq-accordion accordion mb-5">
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-3-1">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-3-1" aria-expanded="true" aria-controls="faq-accordion-collapse-3-1">
              Bring of had which their whose you're it own?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-3-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-heading-3-1" data-bs-parent="#faq_accordion_3">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-3-2">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-3-2" aria-expanded="false" aria-controls="faq-accordion-collapse-3-2">
              Over shall air can't subdue fly divide him?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-3-2" class="accordion-collapse collapse" aria-labelledby="faq-accordion-heading-3-2" data-bs-parent="#faq_accordion_3">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
        <div class="accordion-item">
          <h5 class="accordion-header" id="faq-accordion-heading-3-3">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-3-3" aria-expanded="false" aria-controls="faq-accordion-collapse-3-3">
              Waters one you'll creeping?
              <svg class="accordion-button__icon" viewBox="0 0 14 14"><g aria-hidden="true" stroke="none" fill-rule="evenodd"><path class="svg-path-vertical" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path><path class="svg-path-horizontal" d="M14,6 L14,8 L0,8 L0,6 L14,6"></path></g></svg>
            </button>
          </h5>
          <div id="faq-accordion-collapse-3-3" class="accordion-collapse collapse" aria-labelledby="faq-accordion-heading-3-3" data-bs-parent="#faq_accordion_3">
            <div class="accordion-body">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
            </div>
          </div>
        </div><!-- /.accordion-item -->
      </div>
    </section>
  </main>

  <div class="mb-5 pb-xl-5"></div>
</x-app>